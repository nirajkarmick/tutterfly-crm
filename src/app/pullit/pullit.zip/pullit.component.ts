import {Component, OnInit, ViewChild, Input, Inject, PLATFORM_ID} from '@angular/core';
import {MessageService} from '../message.service';
import {PullitServiceService} from '../service/pullit-service.service';

import {Router} from '@angular/router';
import {Title, Meta} from '@angular/platform-browser';
import {GoogleMapsAPIWrapper, MapsAPILoader} from '@agm/core';
import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {isPlatformBrowser} from '@angular/common';

declare var google;

@Component({
  selector: 'app-pullit',
  templateUrl: './pullit.component.html',
  styleUrls: ['./pullit.component.css']
})
export class PullitComponent implements OnInit {

  constructor(private pullit_service: PullitServiceService,
              private router: Router, private http: HttpClient,
              @Inject(PLATFORM_ID) private platformId: Object,
              private mapsAPILoader: MapsAPILoader) {
  }

  pullit_country = false;
  pullit_keyword = '';
  pullit_search_drop = false;
  pullit_destination = false;
  pullit_poi = false;

  pullit_countryData = [];
  pullit_destData = [];
  pullit_poiData = [];
  showPullIt = false;
  countryData = new CountryData();
  graph_loader = false;
  @Input() oppo: any;

  destinationData = new DestinationData();

  poiData = new PoiData();
  countryLat: any;
  countryLong: any;
  destinationLat: any;
  destinationLong: any;
  poiLat: any;
  poiLong: any;
  // image_path=environment.pullit+'/images/uploads/';
  image_path = 'https://pullit-bucket.s3.us-west-2.amazonaws.com/';
  more_basic = false;
  todaysDay = 'friday';
  opp_dest = '';
  // @Input() showPullIt:any;
  poi_ref_type: any;
  poi_ref_id: any;
  poi_ref_key: any;

  @ViewChild('streetviewMap') streetviewMap: any;
  @ViewChild('streetviewPano') streetviewPano: any;
  latitude = 28.6126823;
  longitude = 77.2295771;
  zoom = 11;
  heading = 34;
  pitch = 10;
  scrollwheel = false;
  country_poi = 15;
  dest_ref_type: any;
  dest_ref_id: any;
  dest_ref_key: any;

  ngOnInit() {
    const address = this.getlatlng('Landon');

    // console.log(address);


  }

  showMoreBasic() {
    this.more_basic = true;
  }

  getlatlng(address) {
    // return this.http.get('https://maps.googleapis.com/maps/api/geocode/json?address=' + address).map((response: Response) => response);
    // return this.http.get('https://maps.googleapis.com/maps/api/geocode/json?address=' + address)
    //  .catch();
  }

  /*pullItExpendWidth() {
    const pullitbigwidth = $(window).width();
    const setpullitbigwidth = pullitbigwidth * 70 / 100;
    $('.pullit-container').css({'width': setpullitbigwidth});
    $('#pullit .card-footer ul').find('.li-hide').show();
    $('#travelexperience figure').removeClass('col-4').addClass('col-2');
    $('#pointofinterest .figure').removeClass('col-4').addClass('col-2');
    $('#topdestinations .figure').removeClass('col-3').addClass('col-2');
    $('#airport figure').removeClass('col-4').addClass('col-2');
    $('.toplocationforexperience figure').removeClass('col-3').addClass('col-2');
    $('.basic-info-itinerary').removeClass('col-6').addClass('col-4');
    $('#experience-category-list ul').removeClass('columns2').addClass('columns3');
    $('#pointofinterst-images figure').removeClass('col-3').addClass('col-2');
    $('#experience-activity .row').find('.col-3').removeClass('col-3').addClass('col-2');
    $('#other-activity-list .row').find('.col-2').removeClass('col-2').addClass('col-1');
    $('.activity-points-list').css('width', '49%');
    $('.activity-points-list:even').css('margin-right', '15px');
    $('.experience-details-box').css('width', '48%');
    $('.unexpend-button').show();
    $('#triangle-left').show();
    $('#limore').hide();
  }

  pullItCollapseWidth() {
    const pullitbigwidth = $(window).width();
    const setpullitsmallwidth = pullitbigwidth * 30 / 100;
    $('.pullit-container').css({'width': setpullitsmallwidth});
    $('#pullit .card-footer ul').find('.li-hide').hide();
    $('#experience-category-list ul').removeClass('columns3').addClass('columns2');
    $('#pointofinterst-images figure').removeClass('col-2').addClass('col-3');
    $('#pointofinterest .figure').removeClass('col-2').addClass('col-4');
    $('#topdestinations .figure').removeClass('col-2').addClass('col-3');
    $('#airport figure').removeClass('col-2').addClass('col-3');
    $('.experience-details-box').css('width', '100%');
    $('#experience-activity .row').find('.col-2').removeClass('col-2').addClass('col-3');
    $('#other-activity-list .row').find('.col-1').removeClass('col-1').addClass('col-2');
    $('.toplocationforexperience figure').removeClass('col-2').addClass('col-3');
    $('.activity-points-list').css('width', '100%');
    $('.activity-points-list').css('margin-right', '0');
    $('.basic-info-itinerary').removeClass('col-4').addClass('col-6');
    $('#limore').show();
    $('#triangle-left').hide();
  }*/


  closePullIt() {
    this.pullit_country = false;
    $('body').css('overflow', 'auto');
    setTimeout(() => {
      $('.modal-background').removeClass('show').addClass('hide');
      $('#modal-skew-from-left').removeClass('show').addClass('hide');
      this.showPullIt = false;
    }, 50);
  }

  /*minimize() {
    $('#pullit-expend').addClass('minimized');
  }

  maximize() {
    $('#pullit-expend').removeClass('minimized');
  }*/

  scrollTodiv(id) {
    document.getElementById(id).scrollIntoView({block: 'start', behavior: 'smooth'});
  }

  search_pullit() {
    if (this.pullit_keyword && this.pullit_keyword.length > 2) {
      this.graph_loader = true;
      this.pullit_search_drop = true;
      this.pullit_countryData = [];
      this.pullit_destData = [];
      this.pullit_poiData = [];
      // api call

      this.pullit_service.pullSearchByKey(this.pullit_keyword).subscribe((data: any) => {
        this.country_poi = 15;
        // console.log(data);
        this.pullit_countryData = data.country;
        this.pullit_destData = data.destination;
        this.pullit_poiData = data.poi;
        this.graph_loader = false;
      }, error => {
        this.graph_loader = false;
      });

    } else {
      this.pullit_search_drop = false;
      this.graph_loader = false;
    }

  }

  renderStreetView(lat, long) {
    if (isPlatformBrowser(this.platformId)) {
      this.mapsAPILoader.load().then(() => {
        const center = {lat: lat, lng: long};
        const map = new window['google'].maps.Map(this.streetviewMap.nativeElement, {
          center: center,
          zoom: this.zoom,
          scrollwheel: this.scrollwheel
        });
        const panorama = new window['google'].maps.StreetViewPanorama(
          this.streetviewPano.nativeElement, {
            position: center,
            pov: {heading: this.heading, pitch: this.pitch},
            scrollwheel: this.scrollwheel
          });
        map.setStreetView(panorama);
      });
    }
  }


  showMoreCountryPoi() {
    this.country_poi = this.country_poi + 15;
  }

  showLessCountryPoi() {
    this.country_poi = 15;
  }

  pullit_country_result(country_id, keyword) {
    this.country_poi = 15;
    this.resetCountryData();
    this.graph_loader = true;
    this.pullit_keyword = keyword;
    this.pullit_service.pullSearchByCountry(country_id).subscribe((data: any) => {
      this.graph_loader = false;
      console.log(data.country.poi);
      this.countryData = data.country;
      this.pullit_country = true;
      if (data.country.destinations.length > 0) {
        // alert(this.countryData.destinations.length);
        this.countryLat = parseFloat(data.country.destinations[0].latitude);
        this.countryLong = parseFloat(data.country.destinations[0].longitude);
      }
      setTimeout(() => {
        document.getElementById('flag').scrollIntoView({block: 'start', behavior: 'smooth'});
      }, 200);
    }, error => {
      this.graph_loader = false;
    });
  }

  resetCountryData() {
    this.country_poi = 15;
    this.pullit_keyword = '';
    this.pullit_country = false;
    this.pullit_search_drop = false;
    this.pullit_poi = false;
    this.countryData = new CountryData();
    this.destinationData = new DestinationData();
    this.countryLat = 0.0;
    this.countryLong = 0.0;
    this.more_basic = false;
    this.pullit_destination = false;
  }


  search_poi(id, keyword, ref_type, ref_id, ref_key) {
    this.country_poi = 15;
    this.poi_ref_type = ref_type;
    this.poi_ref_id = ref_id;
    this.poi_ref_key = ref_key;
    this.pullit_country = false;
    this.pullit_destination = false;
    this.pullit_search_drop = false;
    this.pullit_poi = false;
    this.graph_loader = true;
    this.poiData = new PoiData();
    this.pullit_keyword = keyword;
    console.log(this.poiData);
    this.pullit_service.pullSearchByPoi(id).subscribe((data: any) => {
      console.log(data);
      this.pullit_poi = true;
      this.poiData = data.poi;
      this.poiLat = parseFloat(data.poi.attraction_latitude);
      this.poiLong = parseFloat(data.poi.attraction_longitude);
      this.graph_loader = false;

      setTimeout(() => {
        if (this.poiLat && this.poiLong) {
          this.renderStreetView(this.poiLat, this.poiLong);
        }
        document.getElementById('flag').scrollIntoView({block: 'start', behavior: 'smooth'});
      }, 200);
    }, error => {
      this.graph_loader = false;
    });

  }

  getPlaceDescrip(name) {
    this.pullit_service.getPlaceDescription(name).subscribe((data: any) => {
      console.log(data);


    }, error => {
      this.graph_loader = false;
    });
    return 'descriptions';
  }

  back_to_history_frm_des(ref_type, ref_id) {

    this.country_poi = 15;
    console.log(ref_type, ref_id);
    if (ref_type === 'country') {
      this.pullit_country_result(ref_id, this.dest_ref_key);
    }
    if (ref_type === 'destination') {
      this.search_destination(ref_id, this.dest_ref_key, this.dest_ref_type, this.dest_ref_id, this.dest_ref_key);
    }
    if (ref_type === 'poi') {
      this.search_poi(ref_id, this.dest_ref_key, this.poi_ref_type, this.poi_ref_id, this.poi_ref_key);
    }
  }

  back_to_history_frm_poi(ref_type, ref_id) {
    if (ref_type === 'country') {
      this.pullit_country_result(ref_id, this.poi_ref_key);
    }
    if (ref_type === 'destination') {
      this.search_destination(ref_id, this.poi_ref_key, this.dest_ref_type, this.dest_ref_id, this.dest_ref_key);
    }
    if (ref_type === 'poi') {
      this.search_poi(ref_id, this.poi_ref_key, this.poi_ref_type, this.poi_ref_id, this.poi_ref_key);
    }
  }


  search_destination(id, keyword, ref_type = '', ref_id = '', ref_key = '') {
    this.country_poi = 15;
    this.dest_ref_type = ref_type;
    this.dest_ref_id = ref_id;
    this.dest_ref_key = ref_key;
    this.pullit_country = false;
    this.pullit_destination = false;
    this.pullit_search_drop = false;
    this.pullit_poi = false;
    this.destinationData = new DestinationData();
    this.pullit_keyword = keyword;
    this.graph_loader = true;

    this.pullit_service.pullSearchByDestination(id).subscribe((data: any) => {
      console.log(data);
      this.destinationData = data.destination;
      this.destinationLat = parseFloat(data.destination.latitude);
      this.destinationLong = parseFloat(data.destination.longitude);
      this.pullit_destination = true;
      this.graph_loader = false;
      setTimeout(() => {
        document.getElementById('flag').scrollIntoView({block: 'start', behavior: 'smooth'});
      }, 200);
    }, error => {
      this.graph_loader = false;
    });

  }

  pullIt() {
    this.showPullIt = true;
    $('body').css('overflow', 'hidden');
    setTimeout(() => {
      $('.modal-background').addClass('show').removeClass('hide');
      $('#modal-skew-from-left').addClass('show').removeClass('hide');
    }, 50);
    /*if ($('#pullit-expend').hasClass('minimized')) {
      this.maximize();
    }*/
    this.resizePullIt();
    if (localStorage.getItem('opp_dest')) {
      this.opp_dest = localStorage.getItem('opp_dest') ? localStorage.getItem('opp_dest') : '';
      this.pullit_keyword = this.opp_dest;
      const dest_id = localStorage.getItem('opp_dest_id');
      this.pullit_service.pullSearchByGeoname(dest_id).subscribe((data: any) => {
        console.log(data.destination);
        if (data.destination && data.destination.id) {
          this.search_destination(data.destination.id, this.opp_dest);
        }
      }, error => {
      });
      // this.search_pullit();
    }
  }

  resizePullIt() {
    setTimeout(() => {
      const pullitwidth = $(window).width();
      const setpullitwidth = pullitwidth * 30 / 100;
      const setpullitbodywidth = pullitwidth * 50 / 100;
      const pullitheight = $('#pullit').innerHeight();
      if ($(window).width() > 1024) {
        $('.pullit-container .card-header-sticky').css({'width': (setpullitwidth) + 'px'});
        $('.pullit-body').css({'height': (pullitheight) + 'px', 'width': (setpullitbodywidth) + 'px'});
        /*$('.pullit-body').css({});*/
      } else {
        $('.pullit-container .card-header-sticky').css({'width': (pullitwidth - 20) + 'px'});
      }


      /*$('#pullit-expend').css({'min-height': (pullitheight) + 'px'});*/
    }, 20);
  }
}

class CountryData {
  destinations: any;
  currency: any;
  time_zone: any;
  climate_types: any;
  demonyms: any;
  electrical_sockets: any;
  religions: any;
  ethnicities: any;
  time_zones: any;
  best_time_to_visits: any;
  languages: any;
  airport: any;
}

class DestinationData {
  poi: any;
  country: any;
  airports: any;
}

class PoiData {
  images: any;
  destination: any;
}
